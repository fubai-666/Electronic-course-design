#ifndef __MOTO_H
#define __MOTO_H

#include "stm32f10x.h"

#define GO    0//������״̬ ǰ��
#define BACK  1//����
#define STOP  2//ͣ��

//���õ���������ĸ�����
#define MOTOAB_CLK   RCC_APB2Periph_GPIOB
#define MOTOAB_PORT  GPIOB
#define MOTOAB_Pin1  GPIO_Pin_12
#define MOTOAB_Pin2  GPIO_Pin_13
#define MOTOAB_Pin3  GPIO_Pin_14
#define MOTOAB_Pin4  GPIO_Pin_15

#define MOTOCD_CLK   RCC_APB2Periph_GPIOB
#define MOTOCD_PORT  GPIOB
#define MOTOCD_Pin1  GPIO_Pin_6
#define MOTOCD_Pin2  GPIO_Pin_7
#define MOTOCD_Pin3  GPIO_Pin_8
#define MOTOCD_Pin4  GPIO_Pin_9

/* ���κ꣬��������������һ��ʹ�� */
#define AB_IN1(a)	if (a)	\
					GPIO_SetBits(MOTOAB_PORT,MOTOAB_Pin1);\
					else		\
					GPIO_ResetBits(MOTOAB_PORT,MOTOAB_Pin1)
					
#define AB_IN2(a)	if (a)	\
					GPIO_SetBits(MOTOAB_PORT,MOTOAB_Pin2);\
					else		\
					GPIO_ResetBits(MOTOAB_PORT,MOTOAB_Pin2)
					
#define AB_IN3(a)	if (a)	\
					GPIO_SetBits(MOTOAB_PORT,MOTOAB_Pin3);\
					else		\
					GPIO_ResetBits(MOTOAB_PORT,MOTOAB_Pin3)
					
#define AB_IN4(a)	if (a)	\
					GPIO_SetBits(MOTOAB_PORT,MOTOAB_Pin4);\
					else		\
					GPIO_ResetBits(MOTOAB_PORT,MOTOAB_Pin4)
					
#define CD_IN1(a)	if (a)	\
					GPIO_SetBits(MOTOCD_PORT,MOTOCD_Pin1);\
					else		\
					GPIO_ResetBits(MOTOCD_PORT,MOTOCD_Pin1)
					
#define CD_IN2(a)	if (a)	\
					GPIO_SetBits(MOTOCD_PORT,MOTOCD_Pin2);\
					else		\
					GPIO_ResetBits(MOTOCD_PORT,MOTOCD_Pin2)
					
#define CD_IN3(a)	if (a)	\
					GPIO_SetBits(MOTOCD_PORT,MOTOCD_Pin3);\
					else		\
					GPIO_ResetBits(MOTOCD_PORT,MOTOCD_Pin3)
					
#define CD_IN4(a)	if (a)	\
					GPIO_SetBits(MOTOCD_PORT,MOTOCD_Pin4);\
					else		\
					GPIO_ResetBits(MOTOCD_PORT,MOTOCD_Pin4)
					
#define E_IN1(a)	if (a)	\
					GPIO_SetBits(GPIOB,GPIO_Pin_10);\
					else		\
					GPIO_ResetBits(GPIOB,GPIO_Pin_10)
					
#define E_IN2(a)	if (a)	\
					GPIO_SetBits(GPIOB,GPIO_Pin_11);\
					else		\
					GPIO_ResetBits(GPIOB,GPIO_Pin_11)

void MOTO_GPIO_Config(void);
					
void MOTO_A(char state);
void MOTO_B(char state);
void MOTO_C(char state);
void MOTO_D(char state);		
void MOTO_E(char state);
					
void Car_Go(void);
void Car_Back(void);
void Car_Turn_Right(void);
void Car_Turn_Left(void);
void Car_Stop(void);
					
#endif
