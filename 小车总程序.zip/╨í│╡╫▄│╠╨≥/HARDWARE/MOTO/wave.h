#ifndef __WAVE_H
#define __WAVE_H

#include "bsp_sys.h"
#include "stm32f10x.h"

#define Wave_ON()  GPIO_SetBits(GPIOA,GPIO_Pin_11)
#define Wave_OFF() GPIO_ResetBits(GPIOA,GPIO_Pin_11)

#define Wave_State()  GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_12)

void Wave_IO_Init(void);
u16 Wave_Start(void);
void Wave_BZ(void);;
void Wave_BZ2(void);

#endif

