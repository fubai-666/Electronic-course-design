#ifndef BSP_NVIC_H
#define BSP_NVIC_H

#include "stm32f10x.h"
void NVIC_Config(void);
void NVIC_uart1_Config(void);
void NVIC_TIM3_Config(void);



#endif
