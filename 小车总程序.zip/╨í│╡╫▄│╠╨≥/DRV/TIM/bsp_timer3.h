#ifndef __BSP_TIMER3_H
#define __BSP_TIMER3_H


#include "stm32f10x.h"
void Timer3_Init(u32 arr,int psc);
void MOTO_PWM_Init(u32 arr, int psc);
void MOTO_PWM_Out_AB(u16 moto_A, u16 moto_B);
void MOTO_PWM_Out_CD(u16 moto_C, u16 moto_D);
void MOTO_PWM_Out_E(u16 moto_E);


#endif

